let frutas = [
   'morango',
   'laranja',
   'uva',
   'framboesa',
   'goiaba',
   'mamão',
   'caju',
   'jaca',
   'melancia',
   'cupuaçu',
   'acerola',
   'abacate',
   'cajá',
   'manga',
   'melão',
   'abacaxi',
   'tangerina',
   'banana',
   'limão',
   'ameixa'
]

module.exports = frutas